#!/usr/bin/env python3
"""Compile real warehouse/recovery/transfer classes against small in-memory fixtures.
These are server-thread logic tests, not Fabric compilation or gameplay validation.
"""
from pathlib import Path
import tempfile, subprocess, textwrap, os
PROJECT=Path(__file__).resolve().parents[2]
SOURCE=PROJECT/'common/src/main/java'
STUBS={
'net/minecraft/core/BlockPos.java': '''package net.minecraft.core;
public record BlockPos(int x,int y,int z) {
 public static final BlockPos ZERO=new BlockPos(0,0,0);
 public int getX(){return x;}public int getY(){return y;}public int getZ(){return z;}
 public BlockPos immutable(){return this;}public BlockPos offset(int x,int y,int z){return new BlockPos(this.x+x,this.y+y,this.z+z);}
 public BlockPos above(){return above(1);}public BlockPos above(int n){return offset(0,n,0);}public BlockPos below(){return above(-1);}
 public BlockPos relative(Direction d){return offset(d.x,0,d.z);}public String toShortString(){return x+","+y+","+z;}
 public boolean closerThan(BlockPos p,double n){return Math.pow(x-p.x,2)+Math.pow(y-p.y,2)+Math.pow(z-p.z,2)<n*n;}
}''',
'net/minecraft/core/Direction.java': '''package net.minecraft.core;public enum Direction{NORTH(0,-1),SOUTH(0,1),EAST(1,0),WEST(-1,0);final int x,z;Direction(int x,int z){this.x=x;this.z=z;}public static class Plane{public static final Direction[] HORIZONTAL=values();}}''',
'net/minecraft/world/item/Item.java': '''package net.minecraft.world.item;public record Item(String id){public ItemStack getDefaultInstance(){return new ItemStack(this,1);}}''',
'net/minecraft/world/item/ItemStack.java': '''package net.minecraft.world.item;
public class ItemStack{public static final ItemStack EMPTY=new ItemStack(new Item("empty"),0);private Item item;private int n;public String components="";
 public ItemStack(Item item,int n){this.item=item;this.n=n;}public boolean isEmpty(){return n<=0;}public boolean is(Item i){return item.equals(i);}
 public Item getItem(){return item;}public int getCount(){return n;}public int getMaxStackSize(){return 64;}public void grow(int n){this.n+=n;}public void shrink(int n){this.n-=n;}
 public ItemStack split(int n){int take=Math.min(n,this.n);this.n-=take;var s=new ItemStack(item,take);s.components=components;return s;}
 public ItemStack copyWithCount(int n){var s=new ItemStack(item,n);s.components=components;return s;}
 public static boolean matches(ItemStack a,ItemStack b){return a.n==b.n&&isSameItemSameComponents(a,b);}
 public static boolean isSameItemSameComponents(ItemStack a,ItemStack b){return a.item.equals(b.item)&&a.components.equals(b.components);}}
''',
'net/minecraft/core/registries/BuiltInRegistries.java': '''package net.minecraft.core.registries;import net.minecraft.world.item.Item;public class BuiltInRegistries{public static final BuiltInRegistries ITEM=new BuiltInRegistries();public String getKey(Item i){return i.id();}}''',
'net/minecraft/world/Container.java': '''package net.minecraft.world;import net.minecraft.world.item.*;public interface Container{
 int getContainerSize();ItemStack getItem(int i);void setItem(int i,ItemStack s);default int getMaxStackSize(){return 64;}
 default boolean canPlaceItem(int i,ItemStack s){return true;}default void setChanged(){}default int countItem(Item item){int n=0;for(int i=0;i<getContainerSize();i++)if(getItem(i).is(item))n+=getItem(i).getCount();return n;}
 default ItemStack removeItem(int i,int n){return getItem(i).split(n);}}
''',
'net/minecraft/world/WorldlyContainer.java': '''package net.minecraft.world;import net.minecraft.world.item.*;public interface WorldlyContainer extends Container{boolean canPlaceItemThroughFace(int slot,ItemStack item,Object face);}''',
'net/minecraft/world/phys/Vec3.java': '''package net.minecraft.world.phys;public record Vec3(double x,double y,double z){public double distanceToSqr(double x,double y,double z){return Math.pow(this.x-x,2)+Math.pow(this.y-y,2)+Math.pow(this.z-z,2);}}''',
'net/minecraft/world/level/block/Blocks.java': '''package net.minecraft.world.level.block;public class Blocks{public static final String CHEST="chest";}''',
'net/minecraft/server/level/ServerLevel.java': '''package net.minecraft.server.level;
import java.util.*;import net.minecraft.core.*;import net.minecraft.world.*;
public class ServerLevel{
 public long time;public Map<BlockPos,Container> containers=new HashMap<>();public Set<BlockPos> protectedBlocks=new HashSet<>();
 public boolean hasChunkAt(BlockPos p){return true;}public long getGameTime(){return time;}public Dim dimension(){return new Dim();}
 public Object getBlockEntity(BlockPos p){return containers.get(p);}public State getBlockState(BlockPos p){return new State(containers.containsKey(p));}
 public Fluid getFluidState(BlockPos p){return new Fluid();}public record Fluid(){public boolean isEmpty(){return true;}}
 public record Dim(){public String location(){return "minecraft:overworld";}}
 public record State(boolean chest){public boolean is(String block){return chest&&block.equals("chest");}public boolean isAir(){return !chest;}public boolean isSolidRender(ServerLevel w,BlockPos p){return true;}}
}''',
'com/player2/playerengine/automaton/api/entity/LivingEntityInventory.java': '''package com.player2.playerengine.automaton.api.entity;
import java.util.*;import net.minecraft.world.item.*;public class LivingEntityInventory{
 public final List<ItemStack> main=new ArrayList<>(Collections.nCopies(36,ItemStack.EMPTY));public ItemStack getItem(int i){return main.get(i);}public int getMaxStackSize(){return 64;}public void setChanged(){}
 public void insertStack(ItemStack stack){for(int i=0;i<36&&!stack.isEmpty();i++){ItemStack s=main.get(i);if(s.isEmpty()){main.set(i,stack.split(Math.min(64,stack.getCount())));}else if(ItemStack.isSameItemSameComponents(s,stack)){int n=Math.min(64-s.getCount(),stack.getCount());s.grow(n);stack.shrink(n);}}}}
''',
'com/player2/playerengine/PlayerEngineController.java': '''package com.player2.playerengine;
import net.minecraft.core.*;import net.minecraft.world.item.*;import net.minecraft.world.phys.*;import net.minecraft.server.level.*;import com.player2.playerengine.automaton.api.entity.*;
public class PlayerEngineController{
 public final ServerLevel world=new ServerLevel();public final LivingEntityInventory inventory=new LivingEntityInventory();public final Entity entity=new Entity();public final Behaviour behaviour=new Behaviour();public String identity="test";
 public ServerLevel getWorld(){return world;}public LivingEntityInventory getInventory(){return inventory;}public Entity getEntity(){return entity;}public Storage getItemStorage(){return new Storage();}public Behaviour getBehaviour(){return behaviour;}public Data getAIPersistantData(){return new Data();}
 public class Data{public String getCharacterId(){return identity;}}
 public class Entity{public BlockPos pos=BlockPos.ZERO;public double distanceToSqr(double x,double y,double z){return position().distanceToSqr(x,y,z);}public Vec3 position(){return new Vec3(pos.x(),pos.y(),pos.z());}public BlockPos blockPosition(){return pos;}}
 public class Storage{public int getItemCountInventoryOnly(Item... items){int n=0;for(var s:inventory.main)for(var i:items)if(s.is(i))n+=s.getCount();return n;}public int getItemCount(Item... items){return getItemCountInventoryOnly(items);}}
 public class Behaviour{public java.util.Set<Item> protectedItems=new java.util.HashSet<>();public boolean isProtected(Item i){return protectedItems.contains(i);}}
}''',
'com/player2/playerengine/tasks/base/Task.java': '''package com.player2.playerengine.tasks.base;
import com.player2.playerengine.PlayerEngineController;import java.util.function.Predicate;
public abstract class Task{
 public PlayerEngineController controller;private boolean stopped,started;public Task child;
 public void step(PlayerEngineController c){controller=c;if(!started){onStart();started=true;}Task next=onTick();if(next!=null){child=next;next.step(c);}}
 public void stop(){stopped=true;if(started)onStop(null);if(child!=null)child.stop();}public boolean stopped(){return stopped;}
 public boolean isFinished(){return false;}public boolean containsTask(Predicate<Task> test){return test.test(this)||child!=null&&child.containsTask(test);}
 protected void setDebugState(String s){}protected abstract void onStart();protected abstract Task onTick();protected abstract void onStop(Task next);protected abstract boolean isEqual(Task t);protected abstract String toDebugString();
}''',
'com/player2/playerengine/tasks/ResourceTask.java': '''package com.player2.playerengine.tasks;import com.player2.playerengine.tasks.base.Task;import com.player2.playerengine.util.ItemTarget;
public class ResourceTask extends Task{public boolean finished;public ItemTarget[] targets={};public ItemTarget[] getItemTargets(){return targets;}public boolean isFinished(){return finished;}protected void onStart(){}protected Task onTick(){return null;}protected void onStop(Task n){}protected boolean isEqual(Task t){return this==t;}protected String toDebugString(){return "resource";}}
''',
'com/player2/playerengine/schematic/SchematicProjectTask.java': '''package com.player2.playerengine.schematic;import com.player2.playerengine.tasks.base.Task;import com.player2.playerengine.tasks.ResourceTask;import com.player2.playerengine.PlayerEngineController;public class SchematicProjectTask extends ResourceTask{public boolean reservesMaterial(String id){return id.equals("minecraft:stone");}public static boolean isProjectMaterial(PlayerEngineController mod,String id){return id.equals("minecraft:stone");}}
''',
'com/player2/playerengine/util/ItemTarget.java': '''package com.player2.playerengine.util;import net.minecraft.world.item.*;public record ItemTarget(Item item){public boolean matches(Item i){return item.equals(i);}}''',
'com/player2/playerengine/tasks/movement/GetToBlockTask.java': '''package com.player2.playerengine.tasks.movement;import com.player2.playerengine.tasks.base.Task;import net.minecraft.core.BlockPos;public class GetToBlockTask extends Task{
 private final BlockPos target;public GetToBlockTask(BlockPos p){target=p;}protected void onStart(){}protected Task onTick(){controller.entity.pos=target;return null;}protected void onStop(Task n){}protected boolean isEqual(Task t){return this==t;}protected String toDebugString(){return "fixture travel";}}
''',
'com/player2/playerengine/tasks/crafting/DescribesProgress.java': '''package com.player2.playerengine.tasks.crafting;public interface DescribesProgress{String describeProgress();}''',
'com/player2/playerengine/tasks/deferred/DeferredJobStore.java': '''package com.player2.playerengine.tasks.deferred;import java.nio.file.*;public class DeferredJobStore{public static Path root;public static DeferredJobStore get(){return new DeferredJobStore();}public Path worldRoot(){return root;}}
''',
'com/player2/playerengine/agentic/InventorySpace.java': '''package com.player2.playerengine.agentic;import com.player2.playerengine.PlayerEngineController;public class InventorySpace{public record Snapshot(int free){public boolean known(){return free>=0;}public String summary(){return "free="+free;}}public static Snapshot inspect(PlayerEngineController mod){int free=0;for(var s:mod.inventory.main)if(s.isEmpty())free++;return new Snapshot(free);}}
''',
'com/player2/playerengine/agentic/InventoryCleanupStorage.java': '''package com.player2.playerengine.agentic;import com.player2.playerengine.PlayerEngineController;import net.minecraft.core.BlockPos;import java.util.*;public class InventoryCleanupStorage{public static Optional<BlockPos> legacy=Optional.empty();public static Optional<BlockPos> destination(PlayerEngineController m){return legacy;}public static boolean isProjectStorage(PlayerEngineController m,BlockPos p){return m.world.protectedBlocks.contains(p);}}
''',
'com/player2/playerengine/agentic/StorageIntelligence.java': '''package com.player2.playerengine.agentic;public class StorageIntelligence{public static void afterTransfer(Object t){}}
''',
'com/player2/playerengine/safezone/SafeZoneService.java': '''package com.player2.playerengine.safezone;import net.minecraft.core.*;import net.minecraft.server.level.*;public class SafeZoneService{public static boolean protectedAt(ServerLevel w,BlockPos p){return w.protectedBlocks.contains(p);}}
''',
'com/player2/playerengine/observatory/ObservatoryTelemetry.java': '''package com.player2.playerengine.observatory;import java.util.*;public class ObservatoryTelemetry{public static final List<String> events=new ArrayList<>();public static void event(String type,String detail){events.add(type+":"+detail);}}
''',
'com/player2/playerengine/containeraccess/StorageItemArgs.java': '''package com.player2.playerengine.containeraccess;import net.minecraft.world.item.Item;public class StorageItemArgs{public static final int MAX_COUNT=3456;public record ItemQuery(Item item,String displayId,int countOrAll){public boolean isAll(){return countOrAll<0;}}public static String displayIdFor(Item item){return item.id();}}
''',
'com/player2/playerengine/containeraccess/StorageAccessCode.java': '''package com.player2.playerengine.containeraccess;public enum StorageAccessCode{OK,CONTAINER_UNREACHABLE,CONTAINER_TOO_FAR,CONTAINER_MISSING,INSUFFICIENT_ITEMS,INSUFFICIENT_SPACE,ITEM_NOT_ALLOWED,CONTAINER_CHANGED;public String token(){return name();}}
''',
'com/player2/playerengine/containeraccess/ScanReportFormatter.java': '''package com.player2.playerengine.containeraccess;public class ScanReportFormatter{public enum TransferDirection{DEPOSIT,WITHDRAW}public record EntryFailure(StorageAccessCode code,String id,String detail){}public record EntryOutcome(String id,int moved,int requested,int present,String shortReason){}}
''',
'com/player2/playerengine/containeraccess/ResolvedContainer.java': '''package com.player2.playerengine.containeraccess;import net.minecraft.core.BlockPos;import net.minecraft.world.Container;public record ResolvedContainer(Container container,Kind kind,BlockPos canonicalPos,BlockPos secondaryPos){public record Kind(){public String token(){return "double-chest";}}}
''',
'com/player2/playerengine/containeraccess/ContainerResolver.java': '''package com.player2.playerengine.containeraccess;import net.minecraft.core.BlockPos;import net.minecraft.server.level.ServerLevel;public class ContainerResolver{
 public record Resolution(ResolvedContainer resolved,StorageAccessCode code){public boolean ok(){return resolved!=null;}public String detail(){return code.name();}}
 public static Resolution resolve(ServerLevel w,BlockPos p){var c=w.containers.get(p);if(c==null)return new Resolution(null,StorageAccessCode.CONTAINER_MISSING);BlockPos first=p.x()%4==2?p.offset(-1,0,0):p;return new Resolution(new ResolvedContainer(c,new ResolvedContainer.Kind(),first,first.offset(1,0,0)),StorageAccessCode.OK);}
 public static String formatPos(BlockPos p){return p.toShortString();}}
''',
'com/player2/playerengine/containeraccess/ContainerAnimationHelper.java': '''package com.player2.playerengine.containeraccess;public class ContainerAnimationHelper{public static void open(Object w,Object c){}public static void close(Object w,Object c){}}
''',
'com/player2/playerengine/containeraccess/ContainerScanService.java': '''package com.player2.playerengine.containeraccess;public class ContainerScanService{public static void refreshLegacyCache(Object c,Object a,Object b){}}
''',
}
# Construction fixtures model block state, material consumption and builder ownership.
STUBS.update({
'net/minecraft/world/level/block/state/properties/ChestType.java': 'package net.minecraft.world.level.block.state.properties;public enum ChestType{SINGLE,LEFT,RIGHT}',
'net/minecraft/world/level/block/state/properties/Property.java': 'package net.minecraft.world.level.block.state.properties;public record Property<T>(String name){}',
'net/minecraft/world/level/block/Blocks.java': '''package net.minecraft.world.level.block;import net.minecraft.world.level.block.state.BlockState;public class Blocks{
 public record Block(String name){public BlockState defaultBlockState(){return new BlockState(this);}}
 public static final Block CHEST=new Block("chest"),COBBLESTONE=new Block("cobblestone"),STONE=new Block("stone"),AIR=new Block("air"),MAGMA_BLOCK=new Block("magma");}''',
'net/minecraft/world/level/block/state/BlockState.java': '''package net.minecraft.world.level.block.state;
import net.minecraft.world.level.block.*;import net.minecraft.world.level.block.state.properties.*;import net.minecraft.core.*;import net.minecraft.server.level.*;
public class BlockState{
 public final Blocks.Block block;public Direction facing=Direction.NORTH;public ChestType type=ChestType.SINGLE;
 public BlockState(Blocks.Block b){block=b;}public boolean is(Blocks.Block b){return b.equals(block);}public boolean isAir(){return is(Blocks.AIR);}
 public boolean isSolidRender(ServerLevel w,BlockPos p){return !isAir()&&!is(Blocks.CHEST);}
 @SuppressWarnings("unchecked") public <T>T getValue(Property<T> p){return (T)(p.name().equals("facing")?facing:type);}
 public <T>BlockState setValue(Property<T> p,T value){var s=new BlockState(block);s.facing=facing;s.type=type;if(p.name().equals("facing"))s.facing=(Direction)value;else s.type=(ChestType)value;return s;}}
''',
'net/minecraft/world/level/block/ChestBlock.java': '''package net.minecraft.world.level.block;import net.minecraft.core.*;import net.minecraft.world.level.block.state.*;import net.minecraft.world.level.block.state.properties.*;
public class ChestBlock{public static final Property<Direction> FACING=new Property<>("facing");public static final Property<ChestType> TYPE=new Property<>("type");
 public static Direction getConnectedDirection(BlockState s){boolean left=s.type==ChestType.LEFT;return s.facing==Direction.NORTH?(left?Direction.EAST:Direction.WEST):(left?Direction.WEST:Direction.EAST);}}
''',
'net/minecraft/world/item/Items.java': '''package net.minecraft.world.item;public class Items{public static final Item COBBLESTONE=new Item("minecraft:cobblestone"),CHEST=new Item("minecraft:chest");}''',
'com/player2/playerengine/automaton/api/schematic/AbstractSchematic.java': '''package com.player2.playerengine.automaton.api.schematic;import java.util.*;import net.minecraft.world.level.block.state.*;public abstract class AbstractSchematic{public AbstractSchematic(int x,int y,int z){}public abstract BlockState desiredState(int x,int y,int z,BlockState current,List<BlockState> available);}''',
'com/player2/playerengine/nativecommands/NativeAccess.java': '''package com.player2.playerengine.nativecommands;public class NativeAccess{public static Object get(Object obj,String field)throws Exception{return obj.getClass().getField(field).get(obj);}}''',
'com/player2/playerengine/TaskCatalogue.java': '''package com.player2.playerengine;import com.player2.playerengine.tasks.*;import com.player2.playerengine.tasks.base.*;import net.minecraft.world.item.*;
public class TaskCatalogue{public static boolean failMaterials;public static ResourceTask getItemTask(Item item,int amount){return new ResourceTask(){protected Task onTick(){if(!failMaterials){for(int i=0;i<36;i++)if(controller.inventory.main.get(i).isEmpty()){controller.inventory.main.set(i,new ItemStack(item,amount));finished=true;break;}}return null;}};}}
''',
'net/minecraft/server/level/ServerLevel.java': '''package net.minecraft.server.level;
import java.util.*;import net.minecraft.core.*;import net.minecraft.world.*;import net.minecraft.world.level.block.*;import net.minecraft.world.level.block.state.*;
public class ServerLevel{
 public long time;public Map<BlockPos,Container> containers=new HashMap<>();public Set<BlockPos> protectedBlocks=new HashSet<>();public Map<BlockPos,BlockState> blocks=new HashMap<>();
 public boolean hasChunkAt(BlockPos p){return true;}public long getGameTime(){return time;}public Dim dimension(){return new Dim();}
 public Object getBlockEntity(BlockPos p){return containers.get(p);}public BlockState getBlockState(BlockPos p){return blocks.getOrDefault(p,(containers.containsKey(p)?Blocks.CHEST:p.y()<0?Blocks.STONE:Blocks.AIR).defaultBlockState());}
 public Fluid getFluidState(BlockPos p){return new Fluid();}public record Fluid(){public boolean isEmpty(){return true;}}public record Dim(){public String location(){return "minecraft:overworld";}}
}''',
})
STUBS['net/minecraft/core/BlockPos.java']=STUBS['net/minecraft/core/BlockPos.java'].replace('public BlockPos immutable()', 'public BlockPos west(){return offset(-1,0,0);}public BlockPos immutable()')
STUBS['com/player2/playerengine/safezone/SafeZoneService.java']=STUBS['com/player2/playerengine/safezone/SafeZoneService.java'].replace('public static boolean protectedAt','public static boolean deny(ServerLevel w,BlockPos p,String action){return protectedAt(w,p);}public static boolean protectedAt')
STUBS['com/player2/playerengine/PlayerEngineController.java']=STUBS['com/player2/playerengine/PlayerEngineController.java'].replace('public class Behaviour{','''public final Baritone baritone=new Baritone();public Baritone getBaritone(){return baritone;}
 public class Baritone{public final Builder builder=new Builder();public Builder getBuilderProcess(){return builder;}}
 public class Builder{
  public Object schematic,realSchematic;public boolean active;public int placed,cancelled;
  public boolean isActive(){return active;}public void onLostControl(){active=false;cancelled++;schematic=null;realSchematic=null;}
  public void build(String name,com.player2.playerengine.automaton.api.schematic.AbstractSchematic plan,BlockPos target){
   schematic=plan;active=true;var state=plan.desiredState(0,0,0,world.getBlockState(target),java.util.List.of());
   Item material=state.is(net.minecraft.world.level.block.Blocks.CHEST)?net.minecraft.world.item.Items.CHEST:net.minecraft.world.item.Items.COBBLESTONE;
   boolean found=false;for(var stack:inventory.main)if(stack.is(material)&&!stack.isEmpty()){stack.shrink(1);found=true;break;}if(!found)return;
   world.blocks.put(target,state);placed++;
   if(state.is(net.minecraft.world.level.block.Blocks.CHEST)){
    BlockPos first=target.x()%4==2?target.offset(-1,0,0):target;BlockPos second=first.offset(1,0,0);
    var existing=world.containers.get(target.equals(first)?second:first);if(existing==null)existing=new warehousefixture.WarehouseTests.Chest();world.containers.put(target,existing);
   }
  }
 }
 public class Behaviour{public int depth;public void push(){depth++;}public void pop(){depth--;}public void addProtectedItems(Item... items){}public void avoidBlockBreaking(java.util.function.Predicate<BlockPos> p){}public void avoidBlockPlacing(java.util.function.Predicate<BlockPos> p){}''')
STUBS['com/player2/playerengine/containeraccess/ContainerResolver.java']=STUBS['com/player2/playerengine/containeraccess/ContainerResolver.java'].replace('return new Resolution(new ResolvedContainer(c,new ResolvedContainer.Kind(),first,first.offset(1,0,0)),StorageAccessCode.OK);','BlockPos second=first.offset(1,0,0);if(!w.containers.containsKey(first)||!w.containers.containsKey(second))return new Resolution(new ResolvedContainer(c,new ResolvedContainer.Kind(),p,null),StorageAccessCode.OK);return new Resolution(new ResolvedContainer(c,new ResolvedContainer.Kind(),first,second),StorageAccessCode.OK);')
HARNESS='''package warehousefixture;
import java.nio.file.*;import java.util.*;import com.player2.playerengine.*;import com.player2.playerengine.warehouse.*;import com.player2.playerengine.agentic.*;import com.player2.playerengine.tasks.*;import com.player2.playerengine.tasks.base.*;import com.player2.playerengine.tasks.container.*;import com.player2.playerengine.tasks.deferred.*;import com.player2.playerengine.containeraccess.*;import com.player2.playerengine.util.*;import net.minecraft.world.*;import net.minecraft.world.item.*;import net.minecraft.core.*;
public class WarehouseTests{
 static int tests;static final Item DIRT=new Item("minecraft:dirt"),STONE=new Item("minecraft:stone"),WOOD=new Item("minecraft:oak_planks"),GOLD=new Item("minecraft:gold_ingot");
 static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);tests++;System.out.println("PASS "+label);}
 public static class Chest implements Container{ItemStack[] slots=new ItemStack[54];public Chest(){Arrays.fill(slots,ItemStack.EMPTY);}public int getContainerSize(){return 54;}public ItemStack getItem(int n){return slots[n];}public void setItem(int n,ItemStack s){slots[n]=s;}}
 static PlayerEngineController create(String name,int occupied)throws Exception{var mod=new PlayerEngineController();mod.identity=name;for(int i=0;i<occupied;i++)mod.inventory.main.set(i,new ItemStack(DIRT,64));var saved=WarehouseManager.ledger(mod);saved.set("origin","0,0,0");saved.set("dimension","minecraft:overworld");saved.set("requested",4);saved.set("enabled",true);for(var cell:WarehouseLayout.floor(4)){var p=WarehouseManager.at(saved,cell);mod.world.blocks.put(p,net.minecraft.world.level.block.Blocks.COBBLESTONE.defaultBlockState());saved.set("placed."+WarehouseManager.key(p),true);}saved.save();return mod;}
 static BlockPos chest(PlayerEngineController mod,int index,boolean full)throws Exception{var saved=WarehouseManager.ledger(mod);var pair=WarehouseLayout.chests(4).get(index);var first=WarehouseManager.at(saved,pair.first());var second=WarehouseManager.at(saved,pair.second());Chest chest=new Chest();if(full)for(int i=0;i<54;i++)chest.slots[i]=new ItemStack(GOLD,64);mod.world.containers.put(first,chest);mod.world.containers.put(second,chest);saved.set("container."+WarehouseManager.key(first),true);saved.set("secondary."+WarehouseManager.key(first),WarehouseManager.key(second));saved.save();return first;}
 static ResourceTask root(PlayerEngineController mod){var task=new ResourceTask();task.controller=mod;task.targets=new ItemTarget[]{new ItemTarget(WOOD)};return task;}
 static Task advance(ResourceTask root,int ticks){Task choice=null;for(int i=0;i<ticks;i++){root.controller.world.time++;choice=AutoInventoryCleanup.beforeResourceTick(root);if(choice!=null)choice.step(root.controller);}return choice;}
 public static void main(String[] args)throws Exception{
 DeferredJobStore.root=Files.createTempDirectory("warehouse-logic-");
 var four=WarehouseLayout.chests(4);var eight=WarehouseLayout.chests(8);check(eight.subList(0,4).equals(four),"four-to-eight expansion preserves existing pairs");
 check(WarehouseLayout.floor(4).size()==56&&WarehouseLayout.floor(8).size()==112,"bounded rectangular modules");
 Set<WarehouseLayout.Cell> visited=new HashSet<>();var aisle=WarehouseLayout.aisle(8);ArrayDeque<WarehouseLayout.Cell> q=new ArrayDeque<>();q.add(aisle.iterator().next());while(!q.isEmpty()){var p=q.remove();if(!aisle.contains(p)||!visited.add(p))continue;for(int[] d:new int[][]{{1,0},{-1,0},{0,1},{0,-1}})q.add(new WarehouseLayout.Cell(p.x()+d[0],1,p.z()+d[1]));}check(visited.equals(aisle),"all pathways connected after expansion");
 for(var pair:eight)check(aisle.contains(new WarehouseLayout.Cell(pair.first().x(),1,pair.first().z()+(pair.north()?-1:1))),"each chest has aisle access");
 check(WarehousePolicy.needsRecovery(0,4)&&WarehousePolicy.needsRecovery(3,4)&&!WarehousePolicy.needsRecovery(4,4),"36/36 and 33/36 trigger recovery; four free resumes");
 var mod=create("full",36);var first=chest(mod,0,true);var second=chest(mod,1,false);check(WarehouseManager.allocate(mod,DIRT.getDefaultInstance(),Set.of()).pos().equals(second),"full first double chest allocates second");
 var task=root(mod);check(advance(task,120)==null&&InventorySpace.inspect(mod).free()>=4,"full inventory unloads and original resource task resumes");
 check(!task.finished,"recovery retains parent goal instead of marking it complete");
 check(mod.world.containers.get(second).countItem(DIRT)==36*64,"deposit conservation across all 36 slots");
 var partial=create("partial",33);chest(partial,0,false);check(advance(root(partial),120)==null&&InventorySpace.inspect(partial).free()>=4,"33/36 inventory recovers proactively");
 var pickaxe=create("pickaxe",36);chest(pickaxe,0,false);var craft=root(pickaxe);craft.targets=new ItemTarget[]{new ItemTarget(new Item("minecraft:stone_pickaxe"))};check(advance(craft,120)==null&&InventorySpace.inspect(pickaxe).free()>=4,"replacement-pickaxe resource request recovers full inventory before crafting");
 var blocked=create("blocked",36);for(int i=0;i<4;i++)chest(blocked,i,true);Task waiting=advance(root(blocked),200);check(waiting!=null&&!(waiting instanceof BoundedContainerTransferTask)&&InventorySpace.inspect(blocked).free()==0,"all chests full pauses safely without losing inventory");
 var protectedMod=create("reserved",36);chest(protectedMod,0,false);var reservation=new MaterialReservationService();reservation.reserve(protectedMod,DIRT,64);check(!(advance(root(protectedMod),20) instanceof BoundedContainerTransferTask)&&InventorySpace.inspect(protectedMod).free()==0,"active ledger reservations never unloaded");
 var schematic=create("schematic",36);for(int i=0;i<36;i++)schematic.inventory.main.set(i,new ItemStack(STONE,64));chest(schematic,0,false);check(!(advance(root(schematic),20) instanceof BoundedContainerTransferTask),"schematic project supplies retained");
 var gear=create("gear",36);for(int i=0;i<36;i++)gear.inventory.main.set(i,new ItemStack(new Item("minecraft:diamond_pickaxe"),1));chest(gear,0,false);check(!(advance(root(gear),20) instanceof BoundedContainerTransferTask)&&InventorySpace.inspect(gear).free()==0,"valuable tools are never discarded or unloaded");
 var safe=create("safe",36);var p=chest(safe,0,false);safe.world.protectedBlocks.add(p.offset(1,0,0));check(WarehouseManager.allocate(safe,DIRT.getDefaultInstance(),Set.of())==null,"protected double-chest half rejects entire destination");
 var dim=create("dimension",36);chest(dim,0,false);var ledger=WarehouseManager.ledger(dim);ledger.set("dimension","minecraft:the_nether");ledger.save();check(!(advance(root(dim),20) instanceof BoundedContainerTransferTask),"dimension mismatch blocks recovery");
 var noImport=create("legacy",36);var legacy=chest(noImport,0,false);InventoryCleanupStorage.legacy=Optional.of(legacy);var l=WarehouseManager.ledger(noImport);l.set("enabled",false);l.save();check(!(advance(root(noImport),20) instanceof BoundedContainerTransferTask),"warehouse off cannot fall back to legacy chest");InventoryCleanupStorage.legacy=Optional.empty();
 var paused=create("cancel",36);chest(paused,0,false);var original=root(paused);Task active=AutoInventoryCleanup.beforeResourceTick(original);active.step(paused);AutoInventoryCleanup.cancel(original);check(active.stopped()&&InventorySpace.inspect(paused).free()==0,"cancel closes pending recovery before moving items");
 var stackMod=create("stack",0);var stackChest=chest(stackMod,0,true);var c=stackMod.world.containers.get(stackChest);c.setItem(2,new ItemStack(DIRT,60));check(WarehouseManager.capacity(c,DIRT.getDefaultInstance())==4,"allocation uses partial-stack headroom even with no empty slots");
 var organize=create("organize",0);var oa=chest(organize,0,false);var ob=chest(organize,1,false);organize.world.containers.get(oa).setItem(0,new ItemStack(DIRT,60));organize.world.containers.get(ob).setItem(0,new ItemStack(DIRT,20));var sort=new WarehouseOrganizeTask();for(int i=0;i<160;i++){organize.world.time++;sort.step(organize);}check(sort.isSuccessful()&&organize.world.containers.get(oa).countItem(DIRT)==80&&organize.world.containers.get(ob).countItem(DIRT)==0,"bounded organization consolidates matching authorized stock");
 var interrupted=create("organize-cancel",0);var ia=chest(interrupted,0,false);var ib=chest(interrupted,1,false);interrupted.world.containers.get(ia).setItem(0,new ItemStack(DIRT,1));interrupted.world.containers.get(ib).setItem(0,new ItemStack(DIRT,32));var cancelSort=new WarehouseOrganizeTask();for(int i=0;i<100&&interrupted.getItemStorage().getItemCountInventoryOnly(DIRT)==0;i++){interrupted.world.time++;cancelSort.step(interrupted);}cancelSort.stop();check(interrupted.getItemStorage().getItemCountInventoryOnly(DIRT)==32,"cancelled organization retains withdrawn stock");
 var outcome=create("outcome",1);var op=chest(outcome,0,false);var deposit=new BoundedContainerTransferTask(ScanReportFormatter.TransferDirection.DEPOSIT,op,List.of(new StorageItemArgs.ItemQuery(DIRT,"minecraft:dirt",64)));for(int i=0;i<40;i++)deposit.step(outcome);check(deposit.outcome()==BoundedContainerTransferTask.Outcome.MOVED_ALL&&deposit.entryOutcomes().get(0).moved()==64,"deposit reports verified moved amount instead of zero");
 var changed=create("changed",36);var ca=chest(changed,0,false);var cb=chest(changed,1,false);var changing=root(changed);Task chosen=AutoInventoryCleanup.beforeResourceTick(changing);var changedChest=changed.world.containers.get(ca);for(int i=0;i<54;i++)changedChest.setItem(i,new ItemStack(GOLD,64));chosen.step(changed);check(advance(changing,160)==null&&changed.world.containers.get(cb).countItem(DIRT)==2304,"failed transfer retries a different available chest and resumes");
 var replacement=create("replacement",1);var rp=chest(replacement,0,false);var staleTransfer=new BoundedContainerTransferTask(ScanReportFormatter.TransferDirection.DEPOSIT,rp,List.of(new StorageItemArgs.ItemQuery(DIRT,"minecraft:dirt",64)));staleTransfer.step(replacement);Chest swapped=new Chest();replacement.world.containers.put(rp,swapped);replacement.world.containers.put(rp.offset(1,0,0),swapped);staleTransfer.step(replacement);check(staleTransfer.isFinished()&&staleTransfer.outcome()==BoundedContainerTransferTask.Outcome.FAILED&&replacement.getItemStorage().getItemCountInventoryOnly(DIRT)==64,"container replacement during open invalidates transfer without item loss");
 var file=DeferredJobStore.root.resolve("restart.properties");var before=new WarehouseLedger(file);before.set("origin","1,2,3");before.set("requested",8);before.set("placed.1,2,3",true);before.set("snapshot.1,3,3","dirt=64");before.save();var after=new WarehouseLedger(file);check(after.number("requested",0)==8&&after.get("placed.1,2,3","").equals("true")&&after.get("snapshot.1,3,3","").equals("dirt=64"),"restart restores construction and inventory metadata");
 boolean rejected=false;Files.writeString(file,"schema=99\\norigin=1,2,3\\n");try{new WarehouseLedger(file);}catch(java.io.IOException e){rejected=true;}check(rejected,"unsupported persistence schema fails closed");
 var build=create("build",0);build.world.blocks.clear();build.inventory.main.set(0,new ItemStack(net.minecraft.world.item.Items.COBBLESTONE,56));build.inventory.main.set(1,new ItemStack(net.minecraft.world.item.Items.CHEST,8));var builder=new WarehouseBuildTask();for(int i=0;i<200&&!builder.isFinished();i++){build.world.time++;builder.step(build);}check(builder.isSuccessful()&&build.baritone.builder.placed==64&&build.behaviour.depth==0,"warehouse builder completes supported module and restores behavior");
 var initialStock=WarehouseManager.at(WarehouseManager.ledger(build),WarehouseLayout.chests(4).get(0).first());build.world.containers.get(initialStock).setItem(0,new ItemStack(DIRT,12));var expanded=WarehouseManager.ledger(build);expanded.set("requested",8);expanded.set("state","REQUESTED");expanded.save();build.inventory.main.set(0,new ItemStack(net.minecraft.world.item.Items.COBBLESTONE,56));build.inventory.main.set(1,new ItemStack(net.minecraft.world.item.Items.CHEST,8));var extension=new WarehouseBuildTask();for(int i=0;i<200&&!extension.isFinished();i++){build.world.time++;extension.step(build);}check(extension.isSuccessful()&&build.world.containers.get(initialStock).countItem(DIRT)==12&&build.baritone.builder.placed==128,"construction expands four to eight without changing stored items");
 var unsafe=create("unsupported",0);unsafe.world.blocks.clear();unsafe.world.blocks.put(new BlockPos(3,-1,3),net.minecraft.world.level.block.Blocks.AIR.defaultBlockState());var unsafeBuild=new WarehouseBuildTask();unsafeBuild.step(unsafe);check(unsafeBuild.isTerminal()&&!unsafeBuild.isSuccessful()&&unsafe.baritone.builder.placed==0,"unsupported foundation fails before construction");
 var zone=create("zone-build",0);zone.world.blocks.clear();zone.world.protectedBlocks.add(new BlockPos(3,0,3));var zoneBuild=new WarehouseBuildTask();zoneBuild.step(zone);check(zoneBuild.isTerminal()&&!zoneBuild.isSuccessful()&&zone.baritone.builder.placed==0,"Safe Zone obstruction fails before construction");
 var interruptedBuild=create("build-interrupt",0);interruptedBuild.world.blocks.clear();interruptedBuild.inventory.main.set(0,new ItemStack(net.minecraft.world.item.Items.COBBLESTONE,56));interruptedBuild.inventory.main.set(1,new ItemStack(net.minecraft.world.item.Items.CHEST,8));var interruptTask=new WarehouseBuildTask();interruptTask.step(interruptedBuild);interruptTask.stop();check(WarehouseManager.ledger(interruptedBuild).get("state","").equals("BLOCKED")&&interruptedBuild.behaviour.depth==0,"interrupted construction saves progress and restores policy");var resumed=new WarehouseBuildTask();for(int i=0;i<200&&!resumed.isFinished();i++){interruptedBuild.world.time++;resumed.step(interruptedBuild);}check(resumed.isSuccessful()&&interruptedBuild.baritone.builder.placed==64,"resumed construction does not rebuild completed cells");
 var material=create("no-wood",0);material.world.blocks.clear();material.inventory.main.set(0,new ItemStack(net.minecraft.world.item.Items.COBBLESTONE,56));com.player2.playerengine.TaskCatalogue.failMaterials=true;var missingWood=new WarehouseBuildTask();for(int i=0;i<1300&&!missingWood.isFinished();i++){material.world.time++;missingWood.step(material);}com.player2.playerengine.TaskCatalogue.failMaterials=false;check(missingWood.isTerminal()&&!missingWood.isSuccessful()&&material.baritone.builder.placed==0,"unavailable chest materials stop after bounded no-progress interval");
 var foreign=create("foreign-builder",0);foreign.world.blocks.clear();foreign.inventory.main.set(0,new ItemStack(net.minecraft.world.item.Items.COBBLESTONE,56));foreign.inventory.main.set(1,new ItemStack(net.minecraft.world.item.Items.CHEST,8));var own=new WarehouseBuildTask();own.step(foreign);foreign.baritone.builder.schematic=new Object();int cancelled=foreign.baritone.builder.cancelled;own.stop();check(foreign.baritone.builder.cancelled==cancelled&&foreign.baritone.builder.active,"warehouse cancellation does not cancel unrelated builder ownership");
 System.out.println("WarehouseTests: "+tests+" checks passed (in-memory fixtures; no gameplay)");
 }
}
'''
if __name__ == '__main__':
    with tempfile.TemporaryDirectory(prefix='ellie-warehouse-tests-') as tmp:
        tmp=Path(tmp); files=[]
        for rel,text in STUBS.items():
            p=tmp/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text);files.append(str(p))
        p=tmp/'warehousefixture/WarehouseTests.java';p.parent.mkdir();p.write_text(HARNESS);files.append(str(p))
        actual=['warehouse/WarehouseLayout.java','warehouse/WarehouseLedger.java','warehouse/WarehousePolicy.java','warehouse/WarehouseManager.java','agentic/AutoInventoryCleanup.java','agentic/MaterialReservationService.java','tasks/container/BoundedContainerTransferTask.java','tasks/base/TrackedTaskOutcomeProvider.java','warehouse/WarehouseOrganizeTask.java','warehouse/WarehouseBuildTask.java']
        files += [str(SOURCE/'com/player2/playerengine'/p) for p in actual]
        classes=tmp/'classes';classes.mkdir()
        subprocess.run(['javac','--release','21','-d',str(classes),*files],check=True)
        subprocess.run(['java','-ea','-cp',str(classes),'warehousefixture.WarehouseTests'],check=True)
