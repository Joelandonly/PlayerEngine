package com.player2.playerengine.warehouse;

import java.util.*;

/** Pure deterministic modules: 8 x 7 solid floor, four separated doubles, three-wide central aisle. */
public final class WarehouseLayout {
    public static final int MAX_CHESTS = 32;
    public record Cell(int x, int y, int z) {}
    public record Pair(Cell first, Cell second, boolean north) {}
    private WarehouseLayout() {}
    public static List<Pair> chests(int count) {
        if (count < 4 || count > MAX_CHESTS || count % 4 != 0)
            throw new IllegalArgumentException("Capacity must be 4..32 double chests in modules of four");
        List<Pair> result = new ArrayList<>();
        for (int m=0;m<count/4;m++) for(int z : new int[]{1,5}) for(int x : new int[]{1,5})
            result.add(new Pair(new Cell(x,1,m*7+z),new Cell(x+1,1,m*7+z),z==5));
        return List.copyOf(result);
    }
    public static List<Cell> floor(int count) {
        chests(count);
        List<Cell> result = new ArrayList<>();
        for(int z=0;z<count/4*7;z++) for(int x=0;x<8;x++) result.add(new Cell(x,0,z));
        return List.copyOf(result);
    }
    public static Set<Cell> aisle(int count) {
        Set<Cell> result=new LinkedHashSet<>();
        for(Cell floor:floor(count)) result.add(new Cell(floor.x,1,floor.z));
        for(Pair pair:chests(count)){result.remove(pair.first);result.remove(pair.second);}
        return Collections.unmodifiableSet(result);
    }
}
