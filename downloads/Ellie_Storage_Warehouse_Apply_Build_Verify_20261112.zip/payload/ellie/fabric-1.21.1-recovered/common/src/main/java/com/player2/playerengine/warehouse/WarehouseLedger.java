package com.player2.playerengine.warehouse;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Atomic, versioned metadata. Observed contents are informational, never allocation authority. */
public final class WarehouseLedger {
    private final Path file;
    private final Properties values=new Properties();
    private String fault;
    public String fault(){return fault;}
    public WarehouseLedger(Path file) throws IOException {
        this.file=Objects.requireNonNull(file);
        if(Files.exists(file)) {
            try(InputStream in=Files.newInputStream(file)){values.load(in);}
            if(!"1".equals(values.getProperty("schema")))throw new IOException("Unsupported warehouse schema");
        }
    }
    public String get(String key,String fallback){return values.getProperty(key,fallback);}
    public int number(String key,int fallback){return Integer.parseInt(get(key,Integer.toString(fallback)));}
    public boolean exists(){return values.containsKey("origin");}
    public void set(String key,Object value){values.setProperty(key,String.valueOf(value));}
    public void save() throws IOException {
        try{saveAtomic();fault=null;}catch(IOException failure){fault=failure.getMessage();throw failure;}
    }
    private void saveAtomic() throws IOException {
        values.setProperty("schema","1");
        Files.createDirectories(file.getParent());
        Path tmp=Files.createTempFile(file.getParent(),"warehouse-",".tmp");
        try {
            try(OutputStream out=Files.newOutputStream(tmp)){values.store(out,"Ellie authorized warehouse; live validation required");}
            try{Files.move(tmp,file,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}
            catch(AtomicMoveNotSupportedException e){Files.move(tmp,file,StandardCopyOption.REPLACE_EXISTING);}
        }finally{Files.deleteIfExists(tmp);}
    }
}
