package com.player2.playerengine.commands;

import com.player2.playerengine.PlayerEngineController;
import com.player2.playerengine.commands.base.*;
import com.player2.playerengine.supervisor.*;
import com.player2.playerengine.warehouse.*;
import net.minecraft.core.BlockPos;

/** Exact owner native command; construction requires an idle task scheduler. */
public final class EllieStorageCommand extends Command {
    private static final ThreadLocal<PlayerEngineController> OWNER=new ThreadLocal<>();
    public static void asOwner(PlayerEngineController mod,Runnable dispatch){
        OWNER.set(mod);try{dispatch.run();}finally{OWNER.remove();}
    }
    public EllieStorageCommand() throws CommandException {
        super("ellie_storage","ellie_storage init here | expand 4 | resume | status | list | organize | off | on | reserve 1..8 | register x y z. "
            +"Four-double-chest modules, explicit expansion only; flat clear supported terrain required; optional signs use place_sign.",
            new Arg<>(String.class,"operation","status",0,false));
    }
    @Override protected void call(PlayerEngineController mod,ArgParser parser) throws CommandException {
        try {
            String[] args=parser.getArgUnits();String operation=args.length==0?"status":args[0].toLowerCase(java.util.Locale.ROOT);
            if(!operation.equals("status")&&!operation.equals("list")&&OWNER.get()!=mod)
                throw new IllegalArgumentException("Warehouse changes require an authenticated exact owner command");
            WarehouseLedger saved=WarehouseManager.ledger(mod);
            if(operation.equals("status")||operation.equals("list")){finishWithInfo(WarehouseManager.status(mod,operation.equals("list")));return;}
            if(operation.equals("off")||operation.equals("on")){
                if(!saved.exists())throw new IllegalArgumentException("No warehouse initialized");
                saved.set("enabled",operation.equals("on"));saved.save();finishWithInfo("Automatic warehouse use "+operation);return;
            }
            if(operation.equals("reserve")&&args.length==2){int n=Integer.parseInt(args[1]);if(n<1||n>8)throw new IllegalArgumentException("Reserve must be 1..8 slots");saved.set("reserve",n);saved.save();finishWithInfo("Inventory reserve="+n);return;}
            var active=CoreGoalSupervisor.snapshot(mod);
            if(active!=null && (active.status()==GoalLifecycle.Status.RUNNING || active.status()==GoalLifecycle.Status.SUSPENDED))throw new IllegalArgumentException("Another task owns Ellie; finish or explicitly stop it before warehouse construction/registration");
            if(operation.equals("approve_floor")&&args.length==1){
                String issue=WarehouseManager.unavailable(mod,saved);if(issue!=null)throw new IllegalArgumentException(issue);
                java.util.List<BlockPos> approved=new java.util.ArrayList<>();
                for(var cell:WarehouseLayout.floor(saved.number("requested",4))){
                    BlockPos pos=WarehouseManager.at(saved,cell);
                    if(mod.getWorld().getBlockState(pos).is(net.minecraft.world.level.block.Blocks.COBBLESTONE)){
                        if(com.player2.playerengine.safezone.SafeZoneService.protectedAt(mod.getWorld(),pos)
                            ||com.player2.playerengine.agentic.InventoryCleanupStorage.isProjectStorage(mod,pos))throw new IllegalArgumentException("Protected floor at "+pos);
                        approved.add(pos);
                    }
                }
                for(BlockPos pos:approved)saved.set("placed."+WarehouseManager.key(pos),true);saved.save();
                finishWithInfo("Explicitly approved existing cobblestone floor cells="+approved.size()+"; no blocks changed");return;
            }
            if(operation.equals("organize")&&args.length==1){
                String issue=WarehouseManager.unavailable(mod,saved);if(issue!=null)throw new IllegalArgumentException(issue);
                ProjectTaskGateway.run(mod,new WarehouseOrganizeTask(),()->finishWithInfo("Warehouse organization ended; see task outcome"));return;
            }
            if(operation.equals("init")&&args.length==2&&args[1].equalsIgnoreCase("here")){
                if(saved.exists())throw new IllegalArgumentException("Warehouse already initialized; use resume or expand 4");
                saved.set("origin",WarehouseManager.key(mod.getEntity().blockPosition()));saved.set("dimension",WarehouseManager.dimension(mod));
                saved.set("enabled",true);saved.set("requested",4);saved.set("reserve",4);saved.set("state","REQUESTED");saved.save();
                WarehouseManager.event("WAREHOUSE_INITIALIZED",WarehouseManager.dimension(mod)+" "+saved.get("origin","")+" requested=4");
            }else if(operation.equals("expand")&&args.length==2&&args[1].equals("4")){
                String issue=WarehouseManager.unavailable(mod,saved);if(issue!=null)throw new IllegalArgumentException(issue);
                if(!saved.exists() || !saved.get("state","").equals("READY"))throw new IllegalArgumentException("Finish current warehouse construction first");
                int count=saved.number("requested",4)+4;WarehouseLayout.chests(count);saved.set("requested",count);saved.set("state","REQUESTED");saved.save();
                WarehouseManager.event("WAREHOUSE_EXPANSION_STARTED","requested="+count+" "+saved.get("dimension",""));
            }else if(operation.equals("register")&&args.length==4){
                String issue=WarehouseManager.unavailable(mod,saved);if(issue!=null)throw new IllegalArgumentException(issue);
                BlockPos pos=new BlockPos(Integer.parseInt(args[1]),Integer.parseInt(args[2]),Integer.parseInt(args[3]));
                for(var pair:WarehouseLayout.chests(saved.number("requested",4))){
                    BlockPos first=WarehouseManager.at(saved,pair.first()),second=WarehouseManager.at(saved,pair.second());
                    if(first.equals(pos)||second.equals(pos)){
                        WarehouseManager.registerPair(mod,saved,first,second);saved=WarehouseManager.ledger(mod);
                        saved.set("placed."+WarehouseManager.key(first),true);saved.set("placed."+WarehouseManager.key(second),true);saved.save();
                        finishWithInfo("Explicit warehouse chest approval saved; contents retained");return;
                    }
                }
                throw new IllegalArgumentException("Chest must occupy a planned warehouse pair; legacy cleanup registrations are never imported");
            }else if(!operation.equals("resume")||args.length!=1)throw new IllegalArgumentException("Usage: ellie_storage init here | expand 4 | resume | status | list | organize | off | on | reserve 1..8 | register x y z");
            WarehouseBuildTask.validate(mod,saved);
            ProjectTaskGateway.run(mod,new WarehouseBuildTask(),()->finishWithInfo("Warehouse task ended; use ellie_storage status for verified state"));
        }catch(Exception failure){finishWithError("Warehouse: "+failure.getMessage());}
    }
}
