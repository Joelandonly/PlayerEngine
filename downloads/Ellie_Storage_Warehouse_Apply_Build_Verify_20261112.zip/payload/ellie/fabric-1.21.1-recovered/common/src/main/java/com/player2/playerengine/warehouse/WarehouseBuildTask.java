package com.player2.playerengine.warehouse;

import com.player2.playerengine.TaskCatalogue;
import com.player2.playerengine.automaton.api.schematic.AbstractSchematic;
import com.player2.playerengine.safezone.SafeZoneService;
import com.player2.playerengine.agentic.InventoryCleanupStorage;
import com.player2.playerengine.tasks.base.Task;
import com.player2.playerengine.tasks.base.TrackedTaskOutcomeProvider;
import java.io.IOException;
import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.state.BlockState;

/** Bounded physical construction. No terrain clearing, teleport, setBlock or creative item insertion. */
public final class WarehouseBuildTask extends Task implements TrackedTaskOutcomeProvider {
    private boolean terminal,success,policy,supplies;
    private String reason="Not started";
    private Task action;
    private long actionStart;
    private int lastHeld=-1;
    private long lastGain;
    private BlockPos target;
    private boolean floor;
    private Direction facing;
    private WarehouseLedger saved;
    public static void validate(com.player2.playerengine.PlayerEngineController mod,WarehouseLedger saved) throws IOException {
        String issue=WarehouseManager.unavailable(mod,saved);if(issue!=null)throw new IOException(issue);
        Set<BlockPos> chests=new HashSet<>();
        for(var pair:WarehouseLayout.chests(saved.number("requested",4))){chests.add(WarehouseManager.at(saved,pair.first()));chests.add(WarehouseManager.at(saved,pair.second()));}
        for(var cell:WarehouseLayout.floor(saved.number("requested",4))){
            BlockPos pos=WarehouseManager.at(saved,cell);
            for(int y=-1;y<=3;y++){
                BlockPos check=pos.above(y);
                if(!mod.getWorld().hasChunkAt(check))throw new IOException("Unloaded terrain at "+check);
                if(SafeZoneService.protectedAt(mod.getWorld(),check)||InventoryCleanupStorage.isProjectStorage(mod,check))throw new IOException("Safe Zone/project protection at "+check);
                BlockState state=mod.getWorld().getBlockState(check);
                if(y==-1){
                    if(!state.isSolidRender(mod.getWorld(),check)||!mod.getWorld().getFluidState(check).isEmpty()
                        ||mod.getWorld().getBlockEntity(check)!=null||state.is(Blocks.MAGMA_BLOCK))throw new IOException("Unsupported/dangerous foundation at "+check);
                }else {
                    boolean owned="true".equals(saved.get("placed."+WarehouseManager.key(check),"false"));
                    if(y==0 && owned && state.is(Blocks.COBBLESTONE))continue;
                    if(y==1 && owned && chests.contains(check) && state.is(Blocks.CHEST))continue;
                    if(!state.isAir()||!mod.getWorld().getFluidState(check).isEmpty())throw new IOException("Obstruction/unapproved block at "+check+"; no clearing permitted");
                }
            }
        }
        // One-block ascent from the authorized origin provides an entrance to the connected aisle.
        BlockPos entry=WarehouseManager.origin(saved).west();
        if(!mod.getWorld().getBlockState(entry).isAir() || !mod.getWorld().getBlockState(entry.above()).isAir()
            || !mod.getWorld().getBlockState(entry.below()).isSolidRender(mod.getWorld(),entry.below()))throw new IOException("Warehouse west entrance is obstructed/unsupported");
    }
    @Override protected void onStart(){
        try{saved=WarehouseManager.ledger(controller);validate(controller,saved);
            controller.getBehaviour().push();supplies=true;controller.getBehaviour().addProtectedItems(Items.COBBLESTONE,Items.CHEST);
        }
        catch(Exception failure){finish(false,failure.getMessage());}
    }
    private void enterPlacementPolicy(){
        if(policy)return;
        controller.getBehaviour().push();policy=true;
        controller.getBehaviour().avoidBlockBreaking(pos->true);
        controller.getBehaviour().avoidBlockPlacing(pos->!pos.equals(target));
        controller.getBehaviour().addProtectedItems(Items.CHEST,Items.COBBLESTONE);
    }
    private void leavePlacementPolicy(){if(policy){controller.getBehaviour().pop();policy=false;}}
    @Override protected Task onTick(){
        if(terminal)return null;
        try {
            saved=WarehouseManager.ledger(controller);
            String issue=WarehouseManager.unavailable(controller,saved);if(issue!=null){finish(false,issue);return null;}
            if(action!=null){
                if(target!=null){
                    validate(controller,saved);
                    BlockState state=controller.getWorld().getBlockState(target);
                    boolean placed=floor?state.is(Blocks.COBBLESTONE):state.is(Blocks.CHEST)&&state.getValue(ChestBlock.FACING)==facing;
                    if(placed){action.stop();action=null;target=null;leavePlacementPolicy();}
                    else if(controller.getWorld().getGameTime()-actionStart>400){finish(false,"WAREHOUSE_PATH_UNREACHABLE: placement exceeded 400 ticks at "+target);return null;}
                    else return action;
                }else{
                    int held=controller.getItemStorage().getItemCountInventoryOnly(floor?Items.COBBLESTONE:Items.CHEST);
                    if(held!=lastHeld){lastHeld=held;lastGain=controller.getWorld().getGameTime();}
                    if(!action.isFinished()){
                        if(controller.getWorld().getGameTime()-lastGain>1200 || controller.getWorld().getGameTime()-actionStart>12000){finish(false,"Material acquisition/crafting made no progress; resume after supplies/access are fixed");return null;}
                        return action;
                    }
                    action.stop();action=null;
                }
            }
            validate(controller,saved);
            int floors=0,missingChests=0;
            for(var cell:WarehouseLayout.floor(saved.number("requested",4)))if(!controller.getWorld().getBlockState(WarehouseManager.at(saved,cell)).is(Blocks.COBBLESTONE))floors++;
            for(var pair:WarehouseLayout.chests(saved.number("requested",4)))for(var cell:List.of(pair.first(),pair.second()))if(!controller.getWorld().getBlockState(WarehouseManager.at(saved,cell)).is(Blocks.CHEST))missingChests++;
            // Obtain one module's supply, using the existing crafting/resource planner. Never demand an enormous stockpile.
            if(floors>0 && controller.getItemStorage().getItemCountInventoryOnly(Items.COBBLESTONE)<Math.min(floors,56)){
                floor=true;action=TaskCatalogue.getItemTask(Items.COBBLESTONE,Math.min(floors,56));return beginAction();
            }
            if(missingChests>0 && controller.getItemStorage().getItemCountInventoryOnly(Items.CHEST)<Math.min(missingChests,8)){
                floor=false;action=TaskCatalogue.getItemTask(Items.CHEST,Math.min(missingChests,8));return beginAction();
            }
            for(var cell:WarehouseLayout.floor(saved.number("requested",4))){
                BlockPos pos=WarehouseManager.at(saved,cell);
                if(controller.getWorld().getBlockState(pos).isAir())return place(pos,true,Direction.NORTH);
            }
            for(var pair:WarehouseLayout.chests(saved.number("requested",4))){
                for(var cell:List.of(pair.first(),pair.second())){
                    BlockPos pos=WarehouseManager.at(saved,cell);
                    if(controller.getWorld().getBlockState(pos).isAir())return place(pos,false,pair.north()?Direction.NORTH:Direction.SOUTH);
                }
                BlockPos first=WarehouseManager.at(saved,pair.first()),second=WarehouseManager.at(saved,pair.second());
                var resolution=com.player2.playerengine.containeraccess.ContainerResolver.resolve(controller.getWorld(),first);
                if(!resolution.ok() || resolution.resolved().secondaryPos()==null
                    || !Set.of(first,second).equals(Set.of(resolution.resolved().canonicalPos(),resolution.resolved().secondaryPos()))
                    || !WarehouseManager.verified(controller,resolution.resolved().canonicalPos()))throw new IOException("Double-chest join/access changed at "+first);
                if(!WarehouseManager.authorized(controller,saved,resolution.resolved().canonicalPos())){
                    WarehouseManager.registerPair(controller,saved,first,second);saved=WarehouseManager.ledger(controller);
                }
            }
            saved.set("state","READY");saved.save();finish(true,"Warehouse ready; "+saved.number("requested",4)+" double chests and connected aisles verified");
        }catch(Exception failure){finish(false,failure.getMessage());}
        return null;
    }
    private Task beginAction(){if(action==null)throw new IllegalStateException("Resource/crafting catalogue has no task for required warehouse material");actionStart=lastGain=controller.getWorld().getGameTime();lastHeld=-1;return action;}
    private Task place(BlockPos pos,boolean isFloor,Direction direction) throws IOException {
        target=pos;floor=isFloor;facing=direction;
        saved.set("placed."+WarehouseManager.key(pos),true);saved.set("state","BUILDING");saved.save();
        enterPlacementPolicy();action=new PlaceCell(pos,isFloor,direction);return beginAction();
    }
    private void finish(boolean ok,String message){
        terminal=true;success=ok;reason=message;
        if(action!=null)action.stop();leavePlacementPolicy();
        if(supplies){controller.getBehaviour().pop();supplies=false;}
        if(controller!=null)try{var receipt=WarehouseManager.ledger(controller);receipt.set("state",ok?"READY":"BLOCKED");receipt.set("reason",message);receipt.save();}catch(Exception ignored){}
        WarehouseManager.event(ok?"WAREHOUSE_BUILD_COMPLETED":"WAREHOUSE_PATH_UNREACHABLE",String.valueOf(message));
    }
    @Override protected void onStop(Task next){if(!terminal)finish(false,"INTERRUPTED; construction receipts retained; use ellie_storage resume");}
    @Override public boolean isFinished(){return terminal;}
    @Override public boolean isTerminal(){return terminal;}
    @Override public boolean isSuccessful(){return terminal&&success;}
    @Override public String controlledReason(){return reason;}
    @Override protected boolean isEqual(Task other){return this==other;}
    @Override protected String toDebugString(){return "Warehouse bounded construction";}
    private static final class PlaceCell extends Task {
        private final BlockPos target;private final boolean floor;private final Direction facing;
        private AbstractSchematic owned;
        private boolean ownsBuilder(){
            if(owned==null)return false;
            try{
                Object builder=controller.getBaritone().getBuilderProcess();
                return com.player2.playerengine.nativecommands.NativeAccess.get(builder,"schematic")==owned
                    ||com.player2.playerengine.nativecommands.NativeAccess.get(builder,"realSchematic")==owned;
            }catch(Exception unavailable){return false;}
        }
        PlaceCell(BlockPos target,boolean floor,Direction facing){this.target=target;this.floor=floor;this.facing=facing;}
        protected void onStart(){}
        protected Task onTick(){
            if(SafeZoneService.deny(controller.getWorld(),target,"warehouse placement"))return null;
            if(!controller.getBaritone().getBuilderProcess().isActive()){
                owned=new AbstractSchematic(1,1,1){
                public BlockState desiredState(int x,int y,int z,BlockState current,List<BlockState> available){
                    if(floor)return Blocks.COBBLESTONE.defaultBlockState();
                    // Vanilla chest placement joins the adjacent half. Do not rebuild a joined chest just to change TYPE.
                    if(current.is(Blocks.CHEST)&&current.getValue(ChestBlock.FACING)==facing)return current;
                    BlockState desired=Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING,facing);
                    for(var type:List.of(net.minecraft.world.level.block.state.properties.ChestType.LEFT,net.minecraft.world.level.block.state.properties.ChestType.RIGHT)){
                        BlockState joined=desired.setValue(ChestBlock.TYPE,type);
                        BlockPos other=target.relative(ChestBlock.getConnectedDirection(joined));
                        BlockState neighbor=controller.getWorld().getBlockState(other);
                        if(neighbor.is(Blocks.CHEST)&&neighbor.getValue(ChestBlock.FACING)==facing)return joined;
                    }
                    return desired;
                }
                };
                controller.getBaritone().getBuilderProcess().build("warehouse authorized cell",owned,target);
            }
            return null;
        }
        protected void onStop(Task next){if(ownsBuilder())controller.getBaritone().getBuilderProcess().onLostControl();}
        protected boolean isEqual(Task other){return this==other;}
        protected String toDebugString(){return "Warehouse cell "+target;}
    }
}
