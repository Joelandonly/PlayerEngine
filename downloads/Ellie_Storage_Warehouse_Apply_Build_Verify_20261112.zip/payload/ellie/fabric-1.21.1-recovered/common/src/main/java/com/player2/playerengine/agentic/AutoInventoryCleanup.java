package com.player2.playerengine.agentic;

import com.player2.playerengine.PlayerEngineController;
import com.player2.playerengine.containeraccess.ScanReportFormatter;
import com.player2.playerengine.containeraccess.StorageItemArgs;
import com.player2.playerengine.observatory.ObservatoryTelemetry;
import com.player2.playerengine.schematic.SchematicProjectTask;
import com.player2.playerengine.tasks.ResourceTask;
import com.player2.playerengine.tasks.base.Task;
import com.player2.playerengine.tasks.container.BoundedContainerTransferTask;
import com.player2.playerengine.util.ItemTarget;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.WeakHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Optional, non-destructive pressure relief *inside* a live resource task.
 * Uses only an explicitly registered chest. Never drops items or changes a parent goal.
 */
public final class AutoInventoryCleanup {
    private AutoInventoryCleanup() {}
    private static final Map<Task, Session> SESSIONS = new WeakHashMap<>();
    /** Conservative by design: no sticks, planks, string, wool, food, tools, armor, or schematic materials. */
    private static final Set<String> SURPLUS = Set.of(
        "minecraft:dirt", "minecraft:coarse_dirt", "minecraft:gravel", "minecraft:granite",
        "minecraft:diorite", "minecraft:andesite", "minecraft:cobblestone", "minecraft:cobbled_deepslate",
        "minecraft:deepslate", "minecraft:tuff", "minecraft:stone", "minecraft:netherrack",
        "minecraft:basalt", "minecraft:blackstone", "minecraft:end_stone", "minecraft:sand",
        "minecraft:red_sand", "minecraft:rotten_flesh", "minecraft:spider_eye",
        "minecraft:bone", "minecraft:arrow"
    );
    private static final class Session {
        BoundedContainerTransferTask transfer;
        BlockPos destination;
        int freeBefore, countBefore;
        Item depositing;
        long nextAttempt;
        String lastPressureReason = "";
        final Set<BlockPos> excluded = new java.util.HashSet<>();
        final Task waiting = new PressurePause();
        boolean recovering,legacy;
    }
    private static final class PressurePause extends Task {
        protected void onStart() {}
        protected Task onTick() { setDebugState("Inventory recovery paused; see INVENTORY_RECOVERY_BLOCKED"); return null; }
        protected void onStop(Task next) {}
        protected boolean isEqual(Task other) { return other instanceof PressurePause; }
        protected String toDebugString() { return "Inventory pressure safety pause (goal retained)"; }
    }
    public static Task continuePending(Task root) {
        Session session = SESSIONS.get(root);
        return session == null || session.transfer == null ? null : choose(root, null);
    }
    public static void cancel(Task root) {
        Session session=SESSIONS.remove(root);
        if(session!=null && session.transfer!=null)session.transfer.stop();
    }
    /** Runs BEFORE ResourceTask.onResourceTick, not after a producer has already acted. */
    public static Task beforeResourceTick(Task root) { return choose(root,null); }
    public static Task choose(Task root, Task normalAction) {
        PlayerEngineController mod=root.controller;
        if(mod==null || mod.getWorld()==null || mod.getEntity()==null)return normalAction;
        Session session=SESSIONS.computeIfAbsent(root,unused->new Session());
        long now=mod.getWorld().getGameTime();
        InventorySpace.Snapshot snapshot=InventorySpace.inspect(mod);
        int reserve=4;
        try { reserve=com.player2.playerengine.warehouse.WarehouseManager.ledger(mod).number("reserve",4); }
        catch(Exception ignored) {}
        if(session.transfer!=null){
            boolean allowed;
            try {
                if(session.legacy)allowed=InventoryCleanupStorage.destination(mod).filter(session.destination::equals).isPresent();
                else {
                    var saved=com.player2.playerengine.warehouse.WarehouseManager.ledger(mod);
                    allowed=com.player2.playerengine.warehouse.WarehouseManager.authorized(mod,saved,session.destination);
                }
            }catch(Exception unavailable){allowed=false;}
            if(!allowed || session.transfer.stopped()&&!session.transfer.isFinished()) {
                session.transfer.stop(); session.transfer=null;session.excluded.add(session.destination);
                return blocked(session, "Storage authorization/access changed or transfer interrupted; original goal retained");
            }
            if(!session.transfer.isFinished())return session.transfer;
            int countAfter=mod.getItemStorage().getItemCountInventoryOnly(session.depositing);
            boolean progress=countAfter<session.countBefore;
            ObservatoryTelemetry.event("INVENTORY_RECOVERY_TRANSFER", "dimension="+com.player2.playerengine.warehouse.WarehouseManager.dimension(mod)
                +" destination="+session.destination+" outcome="+session.transfer.outcome()+" countBefore="+session.countBefore+" countAfter="+countAfter
                +" freeBefore="+session.freeBefore+" freeAfter="+snapshot.free());
            try { com.player2.playerengine.warehouse.WarehouseManager.remember(mod,session.destination); }catch(Exception ignored) {}
            if(!progress)session.excluded.add(session.destination);
            session.transfer=null;
        }
        if(!snapshot.known())return blocked(session,"Cannot verify actual main-inventory capacity; producer paused");
        if(!com.player2.playerengine.warehouse.WarehousePolicy.needsRecovery(snapshot.free(),reserve) || root.isFinished()) {
            if(session.recovering)ObservatoryTelemetry.event("INVENTORY_RECOVERY_COMPLETED","task="+root.getClass().getSimpleName()+" free="+snapshot.free()+" original goal resuming");
            session.recovering=false;session.excluded.clear();session.lastPressureReason="";return normalAction;
        }
        if(session.nextAttempt>now)return session.waiting;
        if(!session.recovering){session.recovering=true;ObservatoryTelemetry.event("INVENTORY_RECOVERY_STARTED","task="+root.getClass().getSimpleName()+" "+snapshot.summary());}
        List<Candidate> candidates=selectSurplus(root);
        if(candidates.isEmpty()){session.nextAttempt=now+100;return blocked(session,"No unreserved surplus; equipment, active requirements and project supplies retained; "+snapshot.summary());}
        BlockPos target=null;int amount=0;Candidate candidate=null;
        boolean warehouseExists=true;
        String reason="No verified authorized destination with capacity; initialize warehouse or request expansion";
        for(Candidate possible:candidates){
        candidate=possible;amount=possible.amount;
        try {
            var saved=com.player2.playerengine.warehouse.WarehouseManager.ledger(mod);warehouseExists=saved.exists();
            if(warehouseExists){
                String issue=com.player2.playerengine.warehouse.WarehouseManager.unavailable(mod,saved);
                if(issue!=null)reason=issue;
                else {
                    var choice=com.player2.playerengine.warehouse.WarehouseManager.allocate(mod,candidate.item.getDefaultInstance(),session.excluded);
                    if(choice!=null){target=choice.pos();amount=Math.min(amount,choice.capacity());}
                    else reason=com.player2.playerengine.warehouse.WarehouseManager.allocationProblem(mod,candidate.item.getDefaultInstance(),session.excluded);
                }
            }
        } catch(Exception failure){reason="Warehouse metadata unavailable: "+failure.getMessage();}
        if(!warehouseExists){
            var legacy=InventoryCleanupStorage.destination(mod);
            if(legacy.isPresent()&&!session.excluded.contains(legacy.get())) {
                var resolved=com.player2.playerengine.containeraccess.ContainerResolver.resolve(mod.getWorld(),legacy.get());
                if(resolved.ok()){
                    int capacity=com.player2.playerengine.warehouse.WarehouseManager.capacity(resolved.resolved().container(),candidate.item.getDefaultInstance());
                    if(capacity>0){target=legacy.get();amount=Math.min(amount,capacity);}
                }
            }
        }
        if(target!=null)break;
        }
        if(target==null || mod.getEntity().distanceToSqr(target.getX()+.5,target.getY()+.5,target.getZ()+.5)>115*115){
            session.nextAttempt=now+100;session.excluded.clear();
            return blocked(session,reason+"; producer paused, original goal retained");
        }
        session.legacy=!warehouseExists;session.lastPressureReason="";session.freeBefore=snapshot.free();session.destination=target;
        session.depositing=candidate.item;session.countBefore=mod.getItemStorage().getItemCountInventoryOnly(candidate.item);
        session.transfer=new BoundedContainerTransferTask(ScanReportFormatter.TransferDirection.DEPOSIT,target,
            List.of(new StorageItemArgs.ItemQuery(candidate.item,candidate.id,amount)));
        return session.transfer;
    }
    private static Task blocked(Session session,String reason){
        if(!reason.equals(session.lastPressureReason)){
            session.lastPressureReason=reason;
            ObservatoryTelemetry.event("INVENTORY_RECOVERY_BLOCKED",reason);
            if(reason.matches(".*full=[1-9][0-9]*.*"))ObservatoryTelemetry.event("WAREHOUSE_CAPACITY_FULL",reason);
        }
        return session.waiting;
    }

    private record Candidate(Item item, String id, int amount) {}
    private static List<Candidate> selectSurplus(Task root) {
        PlayerEngineController mod = root.controller;
        Map<Item, Integer> amounts = new HashMap<>();
        for (int i = 0; i < 36; i++) {
            ItemStack stack = mod.getInventory().getItem(i);
            if (stack.isEmpty() || !ItemStack.isSameItemSameComponents(stack, stack.getItem().getDefaultInstance())) continue;
            Item item = stack.getItem();
            String id = BuiltInRegistries.ITEM.getKey(item).toString();
            if (!SURPLUS.contains(id) || SchematicProjectTask.isProjectMaterial(mod, id)
                || mod.getBehaviour().isProtected(item) || MaterialReservationService.isReserved(mod,item)) continue;
            if (root instanceof SchematicProjectTask project && project.reservesMaterial(id)) continue;
            boolean requiredByTask = root.containsTask(t -> t instanceof ResourceTask resource
                && java.util.Arrays.stream(resource.getItemTargets()).anyMatch(target -> target.matches(item)));
            if (root instanceof ResourceTask resource) {
                for (ItemTarget target : resource.getItemTargets()) {
                    if (target.matches(item)) { requiredByTask = true; break; }
                }
            }
            if (!requiredByTask) amounts.merge(item, stack.getCount(), Integer::sum);
        }
        java.util.ArrayList<Candidate> candidates=new java.util.ArrayList<>();
        for(var entry:amounts.entrySet())candidates.add(new Candidate(entry.getKey(),BuiltInRegistries.ITEM.getKey(entry.getKey()).toString(),Math.min(entry.getValue(),StorageItemArgs.MAX_COUNT)));
        candidates.sort(java.util.Comparator.comparingInt(Candidate::amount).reversed().thenComparing(Candidate::id));
        return List.copyOf(candidates);
    }
}
