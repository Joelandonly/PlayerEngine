package net.minecraft.server.level;
import java.util.*;import net.minecraft.core.*;import net.minecraft.world.*;import net.minecraft.world.level.block.*;import net.minecraft.world.level.block.state.*;
public class ServerLevel{
 public long time;public Map<BlockPos,Container> containers=new HashMap<>();public Set<BlockPos> protectedBlocks=new HashSet<>();public Map<BlockPos,BlockState> blocks=new HashMap<>();
 public boolean hasChunkAt(BlockPos p){return true;}public long getGameTime(){return time;}public Dim dimension(){return new Dim();}
 public Object getBlockEntity(BlockPos p){return containers.get(p);}public BlockState getBlockState(BlockPos p){return blocks.getOrDefault(p,(containers.containsKey(p)?Blocks.CHEST:p.y()<0?Blocks.STONE:Blocks.AIR).defaultBlockState());}
 public Fluid getFluidState(BlockPos p){return new Fluid();}public record Fluid(){public boolean isEmpty(){return true;}}public record Dim(){public String location(){return "minecraft:overworld";}}
}