package net.minecraft.world;import net.minecraft.world.item.*;public interface Container{
 int getContainerSize();ItemStack getItem(int i);void setItem(int i,ItemStack s);default int getMaxStackSize(){return 64;}
 default boolean canPlaceItem(int i,ItemStack s){return true;}default void setChanged(){}default int countItem(Item item){int n=0;for(int i=0;i<getContainerSize();i++)if(getItem(i).is(item))n+=getItem(i).getCount();return n;}
 default ItemStack removeItem(int i,int n){return getItem(i).split(n);}}
