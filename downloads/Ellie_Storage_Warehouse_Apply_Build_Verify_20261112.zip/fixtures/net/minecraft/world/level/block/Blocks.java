package net.minecraft.world.level.block;import net.minecraft.world.level.block.state.BlockState;public class Blocks{
 public record Block(String name){public BlockState defaultBlockState(){return new BlockState(this);}}
 public static final Block CHEST=new Block("chest"),COBBLESTONE=new Block("cobblestone"),STONE=new Block("stone"),AIR=new Block("air"),MAGMA_BLOCK=new Block("magma");}