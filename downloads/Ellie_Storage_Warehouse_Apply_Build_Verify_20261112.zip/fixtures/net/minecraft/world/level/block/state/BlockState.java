package net.minecraft.world.level.block.state;
import net.minecraft.world.level.block.*;import net.minecraft.world.level.block.state.properties.*;import net.minecraft.core.*;import net.minecraft.server.level.*;
public class BlockState{
 public final Blocks.Block block;public Direction facing=Direction.NORTH;public ChestType type=ChestType.SINGLE;
 public BlockState(Blocks.Block b){block=b;}public boolean is(Blocks.Block b){return b.equals(block);}public boolean isAir(){return is(Blocks.AIR);}
 public boolean isSolidRender(ServerLevel w,BlockPos p){return !isAir()&&!is(Blocks.CHEST);}
 @SuppressWarnings("unchecked") public <T>T getValue(Property<T> p){return (T)(p.name().equals("facing")?facing:type);}
 public <T>BlockState setValue(Property<T> p,T value){var s=new BlockState(block);s.facing=facing;s.type=type;if(p.name().equals("facing"))s.facing=(Direction)value;else s.type=(ChestType)value;return s;}}
