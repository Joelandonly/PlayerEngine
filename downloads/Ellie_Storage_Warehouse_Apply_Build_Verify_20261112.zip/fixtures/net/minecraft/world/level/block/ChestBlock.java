package net.minecraft.world.level.block;import net.minecraft.core.*;import net.minecraft.world.level.block.state.*;import net.minecraft.world.level.block.state.properties.*;
public class ChestBlock{public static final Property<Direction> FACING=new Property<>("facing");public static final Property<ChestType> TYPE=new Property<>("type");
 public static Direction getConnectedDirection(BlockState s){boolean left=s.type==ChestType.LEFT;return s.facing==Direction.NORTH?(left?Direction.EAST:Direction.WEST):(left?Direction.WEST:Direction.EAST);}}
