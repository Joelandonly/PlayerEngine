package net.minecraft.world.item;
public class ItemStack{public static final ItemStack EMPTY=new ItemStack(new Item("empty"),0);private Item item;private int n;public String components="";
 public ItemStack(Item item,int n){this.item=item;this.n=n;}public boolean isEmpty(){return n<=0;}public boolean is(Item i){return item.equals(i);}
 public Item getItem(){return item;}public int getCount(){return n;}public int getMaxStackSize(){return 64;}public void grow(int n){this.n+=n;}public void shrink(int n){this.n-=n;}
 public ItemStack split(int n){int take=Math.min(n,this.n);this.n-=take;var s=new ItemStack(item,take);s.components=components;return s;}
 public ItemStack copyWithCount(int n){var s=new ItemStack(item,n);s.components=components;return s;}
 public static boolean matches(ItemStack a,ItemStack b){return a.n==b.n&&isSameItemSameComponents(a,b);}
 public static boolean isSameItemSameComponents(ItemStack a,ItemStack b){return a.item.equals(b.item)&&a.components.equals(b.components);}}
