package net.minecraft.core;
public record BlockPos(int x,int y,int z) {
 public static final BlockPos ZERO=new BlockPos(0,0,0);
 public int getX(){return x;}public int getY(){return y;}public int getZ(){return z;}
 public BlockPos west(){return offset(-1,0,0);}public BlockPos immutable(){return this;}public BlockPos offset(int x,int y,int z){return new BlockPos(this.x+x,this.y+y,this.z+z);}
 public BlockPos above(){return above(1);}public BlockPos above(int n){return offset(0,n,0);}public BlockPos below(){return above(-1);}
 public BlockPos relative(Direction d){return offset(d.x,0,d.z);}public String toShortString(){return x+","+y+","+z;}
 public boolean closerThan(BlockPos p,double n){return Math.pow(x-p.x,2)+Math.pow(y-p.y,2)+Math.pow(z-p.z,2)<n*n;}
}