package com.player2.playerengine;
import net.minecraft.core.*;import net.minecraft.world.item.*;import net.minecraft.world.phys.*;import net.minecraft.server.level.*;import com.player2.playerengine.automaton.api.entity.*;
public class PlayerEngineController{
 public final ServerLevel world=new ServerLevel();public final LivingEntityInventory inventory=new LivingEntityInventory();public final Entity entity=new Entity();public final Behaviour behaviour=new Behaviour();public String identity="test";
 public ServerLevel getWorld(){return world;}public LivingEntityInventory getInventory(){return inventory;}public Entity getEntity(){return entity;}public Storage getItemStorage(){return new Storage();}public Behaviour getBehaviour(){return behaviour;}public Data getAIPersistantData(){return new Data();}
 public class Data{public String getCharacterId(){return identity;}}
 public class Entity{public BlockPos pos=BlockPos.ZERO;public double distanceToSqr(double x,double y,double z){return position().distanceToSqr(x,y,z);}public Vec3 position(){return new Vec3(pos.x(),pos.y(),pos.z());}public BlockPos blockPosition(){return pos;}}
 public class Storage{public int getItemCountInventoryOnly(Item... items){int n=0;for(var s:inventory.main)for(var i:items)if(s.is(i))n+=s.getCount();return n;}public int getItemCount(Item... items){return getItemCountInventoryOnly(items);}}
 public final Baritone baritone=new Baritone();public Baritone getBaritone(){return baritone;}
 public class Baritone{public final Builder builder=new Builder();public Builder getBuilderProcess(){return builder;}}
 public class Builder{
  public Object schematic,realSchematic;public boolean active;public int placed,cancelled;
  public boolean isActive(){return active;}public void onLostControl(){active=false;cancelled++;schematic=null;realSchematic=null;}
  public void build(String name,com.player2.playerengine.automaton.api.schematic.AbstractSchematic plan,BlockPos target){
   schematic=plan;active=true;var state=plan.desiredState(0,0,0,world.getBlockState(target),java.util.List.of());
   Item material=state.is(net.minecraft.world.level.block.Blocks.CHEST)?net.minecraft.world.item.Items.CHEST:net.minecraft.world.item.Items.COBBLESTONE;
   boolean found=false;for(var stack:inventory.main)if(stack.is(material)&&!stack.isEmpty()){stack.shrink(1);found=true;break;}if(!found)return;
   world.blocks.put(target,state);placed++;
   if(state.is(net.minecraft.world.level.block.Blocks.CHEST)){
    BlockPos first=target.x()%4==2?target.offset(-1,0,0):target;BlockPos second=first.offset(1,0,0);
    var existing=world.containers.get(target.equals(first)?second:first);if(existing==null)existing=new warehousefixture.WarehouseTests.Chest();world.containers.put(target,existing);
   }
  }
 }
 public class Behaviour{public int depth;public void push(){depth++;}public void pop(){depth--;}public void addProtectedItems(Item... items){}public void avoidBlockBreaking(java.util.function.Predicate<BlockPos> p){}public void avoidBlockPlacing(java.util.function.Predicate<BlockPos> p){}public java.util.Set<Item> protectedItems=new java.util.HashSet<>();public boolean isProtected(Item i){return protectedItems.contains(i);}}
}