package com.player2.playerengine.automaton.api.entity;
import java.util.*;import net.minecraft.world.item.*;public class LivingEntityInventory{
 public final List<ItemStack> main=new ArrayList<>(Collections.nCopies(36,ItemStack.EMPTY));public ItemStack getItem(int i){return main.get(i);}public int getMaxStackSize(){return 64;}public void setChanged(){}
 public void insertStack(ItemStack stack){for(int i=0;i<36&&!stack.isEmpty();i++){ItemStack s=main.get(i);if(s.isEmpty()){main.set(i,stack.split(Math.min(64,stack.getCount())));}else if(ItemStack.isSameItemSameComponents(s,stack)){int n=Math.min(64-s.getCount(),stack.getCount());s.grow(n);stack.shrink(n);}}}}
