package com.player2.playerengine.tasks.base;
import com.player2.playerengine.PlayerEngineController;import java.util.function.Predicate;
public abstract class Task{
 public PlayerEngineController controller;private boolean stopped,started;public Task child;
 public void step(PlayerEngineController c){controller=c;if(!started){onStart();started=true;}Task next=onTick();if(next!=null){child=next;next.step(c);}}
 public void stop(){stopped=true;if(started)onStop(null);if(child!=null)child.stop();}public boolean stopped(){return stopped;}
 public boolean isFinished(){return false;}public boolean containsTask(Predicate<Task> test){return test.test(this)||child!=null&&child.containsTask(test);}
 protected void setDebugState(String s){}protected abstract void onStart();protected abstract Task onTick();protected abstract void onStop(Task next);protected abstract boolean isEqual(Task t);protected abstract String toDebugString();
}