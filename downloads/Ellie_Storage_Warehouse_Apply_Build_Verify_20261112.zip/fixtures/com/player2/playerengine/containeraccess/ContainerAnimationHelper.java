package com.player2.playerengine.containeraccess;public class ContainerAnimationHelper{public static void open(Object w,Object c){}public static void close(Object w,Object c){}}
